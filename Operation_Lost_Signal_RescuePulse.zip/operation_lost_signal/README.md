# Operation: Lost Signal — Adaptive Rescue Intelligence System

A responsive, front-end hackathon prototype for a search-and-rescue scenario involving six missing trekkers, incomplete telemetry, worsening weather and limited rescue resources.

## What is implemented

- Six synthetic trekker profiles loaded from `data.json`.
- Explainable heuristic risk scoring based on injury reports, battery, signal, ping age, terrain, weather and reported GPS confidence.
- Priority queue with name/ID search and sector/priority filters.
- Editable telemetry with automatic recalculation of scores, summary cards and response suggestions.
- A **Mission Lab** with one-click what-if incidents: critical battery, injury report, stale location and worsening terrain/weather.
- A **location-confidence indicator** combining reported GPS confidence with ping age. This is a demo indicator, not a measured GPS accuracy radius.
- A **simulated offline-first queue**: disconnect the demo network, apply updates, then reconnect and sync the queued event IDs.
- Duplicate event-ID guard in the simulated sync flow and an event/sync audit log.
- Local persistence for edited synthetic telemetry, queued events and audit events using browser `localStorage`.
- Illustrative sector-based resource allocation and information-gap prompts.
- Responsive HTML, CSS and JavaScript; no framework, API key, database or external service required.

## Run locally

Because the app loads `data.json` with `fetch()`, use a local web server rather than double-clicking `index.html`.

### Option A — VS Code Live Server

1. Extract the ZIP.
2. Open the `operation_lost_signal` folder in VS Code.
3. Install the **Live Server** extension if needed.
4. Right-click `index.html` and select **Open with Live Server**.

### Option B — Python server

Open a terminal in the project folder and run:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000` in your browser.

## Project structure

```text
operation_lost_signal/
├── index.html   # Dashboard and Mission Lab UI
├── style.css    # Responsive dashboard styling
├── script.js    # Risk rules, what-if scenarios, queue and UI logic
├── data.json    # Six synthetic trekker profiles
└── README.md    # Setup, assumptions and demo instructions
```

## Risk model

The current score is an additive heuristic capped at 100:

- Reported injury: +25
- Battery: +7 to +20 depending on remaining percentage
- Signal quality: +0 to +15
- Ping age: +5 to +15
- Terrain exposure: +0 to +20
- Weather exposure: +0 to +10
- Reported location uncertainty: +0 to +15

Priority bands are High (60–100), Medium (35–59) and Low (0–34). These are illustrative hackathon weights, not validated operational rescue rules. The score is designed to be explainable; it does not predict survival or guarantee a correct deployment decision. Missing information must not be interpreted as evidence that a person is safe.

## Advanced demo walkthrough

1. Open the dashboard and review the six profiles and risk queue.
2. Select `TRK-05` (or another trekker) from the queue.
3. In **Mission Lab**, click **Battery critical · 5%** or **Location stale · 6h** and observe the score, risk reasons and location-confidence indicator update.
4. Click **Go offline**. Apply another scenario. The app stores the update in its local demo queue and shows a pending count.
5. Click **Reconnect network**, then **Sync queue**. The UI records a simulated sync event and clears the pending queue.
6. Inspect **Recent system events** to show the audit trail.
7. Use **Restore selected profile** to reset the selected trekker, or **Reset data** to restore all profiles and the network simulation.

## What is simulated vs. real

- All people, locations, timestamps, battery values, sensor data, weather and network events are synthetic.
- Offline mode is a **simulation inside this browser app**. It does not turn off the device's actual internet, connect to a real server, or send real messages.
- Sync is simulated; there is no backend server. Local browser storage is used to retain demo telemetry, pending events and audit entries.
- The app does not connect to real GPS, satellite, maps, weather, radio, Bluetooth mesh, messaging or phone battery APIs.
- Team allocation is illustrative grouping by sector. It does not model real travel times, terrain routing, skills, medical protocols or road closures.
- Location confidence is a heuristic label based on supplied confidence and ping age, not a statistically calibrated probability or physical uncertainty radius.

## Next technical extensions

- Add unit tests for risk thresholds and malformed telemetry.
- Add a service worker for stronger offline asset loading.
- Add a backend API with server-side idempotency and authenticated event ingestion.
- Add real map tiles and coordinates only when an approved data source is available.
- Review risk weights with search-and-rescue professionals before any operational use.

## Safety note

This is a decision-support demonstration only. Do not use it for real rescue operations. Recommendations must be checked by trained incident command and official safety procedures.

## ShoeTrace: independent shoe/ankle tracker concept

The dashboard now includes a **ShoeTrace demo panel** to demonstrate the proposed hardware idea: a tracker worn on a shoe or ankle strap can work independently of a damaged/lost phone. Use `Simulate phone broken`, `Receive tracker ping`, and `Tracker battery 5%` to demonstrate the flow. The location values are **synthetic coordinates**, generated for the selected demo sector; they are not live GPS readings and do not identify a real trekker. The OpenStreetMap link is only a map viewer centered on those illustrative coordinates.

### What real hardware would require
- GNSS/GPS receiver and antenna to calculate location (satellites generally do not receive a distress message from a normal GPS receiver).
- Battery, charging/protection circuit, weather-resistant enclosure and a wearable mounting method.
- A separate communication path to send coordinates: cellular/LTE-M/NB-IoT where supported, a compatible radio + gateway, or a suitable satellite messenger/service. Bluetooth alone only reaches a nearby paired phone/gateway.
- A backend/API and map dashboard to receive and display real tracker telemetry.
- Field testing for coverage, battery life, waterproofing, antenna performance, and safety. A shoe-mounted antenna may be blocked by the body/terrain; an ankle strap or pack mount may work better.

This project is a browser-based simulation. It does **not** connect to a physical GPS module, cellular modem, LoRa radio, satellite service, or emergency response network. Do not use it for real rescue operations.


## RescuePulse: Silent SOS + Last Safe Footprint

The new RescuePulse panel adds two judge-demo interactions to ShoeTrace:

1. **Save current footprint** stores the selected synthetic tracker's current demo coordinates and timestamp in the page state.
2. **Activate Silent SOS** creates a local incident state, preserves a last footprint if one has not already been saved, and adds an audit-log event for operator review.
3. **Mark demo alert reviewed** closes the simulated alert and logs the operator action.

### Suggested judging walkthrough

- Select a trekker and open ShoeTrace.
- Click **Save current footprint** to preserve the last known demo position.
- Click **Simulate phone broken** to explain the independent shoe-tracker concept.
- Click **Activate Silent SOS** and point out the active incident and preserved coordinates.
- Mark the demo alert reviewed and show the audit trail.

**Important:** RescuePulse is a front-end simulation. It does not access live GPS, detect falls, transmit an SOS, contact emergency services, or send data to a rescue team. The coordinates and incident are synthetic. A real deployment would need tested wearable hardware, a communications path, a secure backend, consent/privacy controls and validated emergency procedures.

const DEFAULT_DATA_URL = "./data.json";
const state = { trekkers: [], selectedId: "TRK-01", original: null, offline: false, pending: [], audit: [], shoe: { battery: 82, phoneBroken: false, lat: 30.9, lon: 79.0, lastFix: "Just now (demo)", online: true }, lastSafe: null, sosActive: false };
const $ = (selector) => document.querySelector(selector);

const terrainPoints = { "Low": 0, "Medium": 8, "High": 15, "Very high": 20 };
const weatherPoints = { "Low": 0, "Medium": 5, "High": 10 };
const signalPoints = { "Strong": 0, "Moderate": 4, "Intermittent": 8, "Weak": 12, "None": 15 };
const confidencePoints = { "High": 0, "Medium": 5, "Low": 10, "Very low": 15 };

function calculateRisk(t) {
  let score = 0;
  const factors = [];
  const add = (label, points, reason) => {
    score += points;
    if (points > 0) factors.push({ label, points, reason });
  };
  if (t.injury && !/no injury|none|not reported/i.test(t.injury)) add("Reported injury", 25, t.injury);
  if (Number(t.battery) < 10) add("Critical battery", 20, `${t.battery}% battery remaining`);
  else if (Number(t.battery) < 20) add("Low battery", 15, `${t.battery}% battery remaining`);
  else if (Number(t.battery) < 35) add("Reduced battery", 7, `${t.battery}% battery remaining`);
  const signal = signalPoints[t.signal] ?? 8;
  add("Signal quality", signal, `${t.signal} signal`);
  const age = Number(t.pingAgeHours) || 0;
  if (age >= 5) add("Very stale ping", 15, `${age.toFixed(1)} hours since last ping`);
  else if (age >= 3) add("Stale ping", 10, `${age.toFixed(1)} hours since last ping`);
  else if (age >= 1.5) add("Aging ping", 5, `${age.toFixed(1)} hours since last ping`);
  const terrain = terrainPoints[t.terrain] ?? 8;
  add("Terrain exposure", terrain, `${t.terrain} terrain`);
  const weather = weatherPoints[t.weatherExposure] ?? 5;
  add("Weather exposure", weather, `${t.weatherExposure} exposure`);
  const confidence = confidencePoints[t.gpsConfidence] ?? 5;
  add("Location uncertainty", confidence, `${t.gpsConfidence} location confidence`);
  score = Math.min(100, score);
  const priority = score >= 60 ? "High" : score >= 35 ? "Medium" : "Low";
  return { score, priority, factors: factors.sort((a,b) => b.points - a.points) };
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c]));
}
function initials(name) { return name.split(/\s+/).map(x => x[0]).slice(0,2).join("").toUpperCase(); }
function riskClass(priority) { return `risk-${priority.toLowerCase()}`; }
function batteryColor(value) { return value < 15 ? "var(--red)" : value < 35 ? "var(--amber)" : "var(--green)"; }
function enriched(t) { return { ...t, ...calculateRisk(t) }; }
function sortByRisk(a,b) { return b.score - a.score || a.name.localeCompare(b.name); }

async function init() {
  try {
    const response = await fetch(DEFAULT_DATA_URL);
    if (!response.ok) throw new Error("Could not load data.json");
    state.trekkers = await response.json();
    state.original = JSON.parse(JSON.stringify(state.trekkers));
    try {
      const savedTelemetry = JSON.parse(localStorage.getItem("lostSignalTelemetry") || "null");
      if (Array.isArray(savedTelemetry) && savedTelemetry.length === state.trekkers.length) state.trekkers = savedTelemetry;
    } catch {}
    try { state.pending = JSON.parse(localStorage.getItem("lostSignalPending") || "[]"); } catch { state.pending = []; }
    try { state.audit = JSON.parse(localStorage.getItem("lostSignalAudit") || "[]"); } catch { state.audit = []; }
    if (!state.audit.length) logEvent("Prototype ready · six synthetic profiles loaded");
    populateSectorFilter();
    bindEvents();
    render();
    renderShoeTracker();
  } catch (error) {
    $("#trekkerList").innerHTML = `<div class="empty-state"><h4>Data could not be loaded</h4><p>Open this project through VS Code Live Server, not by double-clicking index.html. ${escapeHtml(error.message)}</p></div>`;
  }
}

function populateSectorFilter() {
  const sectors = [...new Set(state.trekkers.map(t => t.sectorCode))].sort();
  $("#sectorFilter").innerHTML = '<option value="all">All sectors</option>' + sectors.map(s => `<option value="${escapeHtml(s)}">${escapeHtml(s)}</option>`).join("");
}
function bindEvents() {
  $("#searchInput").addEventListener("input", renderQueue);
  $("#riskFilter").addEventListener("change", renderQueue);
  $("#sectorFilter").addEventListener("change", renderQueue);
  $("#recalculateBtn").addEventListener("click", () => { render(); toast("Risk scores recalculated from current telemetry."); });
  $("#resetBtn").addEventListener("click", () => {
    state.trekkers = JSON.parse(JSON.stringify(state.original));
    state.selectedId = "TRK-01";
    state.offline = false;
    state.pending = [];
    state.shoe = { battery: 82, phoneBroken: false, lat: 30.9, lon: 79.0, lastFix: "Just now (demo)", online: true }; state.lastSafe = null; state.sosActive = false; renderRescuePulse();
    persistQueue();
    try { localStorage.removeItem("lostSignalTelemetry"); } catch {}
    populateSectorFilter(); render(); renderShoeTracker(); logEvent("Sample data and network simulation reset"); toast("Sample telemetry and simulation reset.");
  });
  $("#toggleNetworkBtn").addEventListener("click", toggleNetwork);
  $("#syncQueueBtn").addEventListener("click", syncQueue);
  $("#clearAuditBtn").addEventListener("click", () => { state.audit = []; persistAudit(); renderAudit(); logEvent("Audit log cleared by operator"); });
  $("#shoePingBtn").addEventListener("click", receiveShoePing);
  $("#saveFootprintBtn").addEventListener("click", saveSafeFootprint);
  $("#silentSosBtn").addEventListener("click", activateSilentSos);
  $("#resolveSosBtn").addEventListener("click", resolveSilentSos);
  $("#phoneBrokenBtn").addEventListener("click", togglePhoneBroken);
  $("#trackerLowBtn").addEventListener("click", () => { state.shoe.battery = 5; renderShoeTracker(); logEvent("ShoeTrace tracker battery simulated at 5%"); $("#shoeMessage").textContent = "Tracker battery is critical. Real hardware should raise a low-power alert."; });
  $("#copyCoordsBtn").addEventListener("click", async () => { const coords = `${state.shoe.lat.toFixed(5)}, ${state.shoe.lon.toFixed(5)}`; try { await navigator.clipboard.writeText(coords); $("#shoeMessage").textContent = `Copied demo coordinates: ${coords}`; } catch { $("#shoeMessage").textContent = `Coordinates: ${coords} (clipboard permission unavailable)`; } });
  $("#missionLab").addEventListener("click", (event) => {
    const button = event.target.closest("[data-scenario]");
    if (button) applyScenario(button.dataset.scenario);
  });
  $("#trekkerList").addEventListener("click", (event) => {
    const row = event.target.closest("[data-id]");
    if (!row) return;
    state.selectedId = row.dataset.id;
    render();
  });
  $("#detailContent").addEventListener("click", (event) => {
    if (event.target.id === "saveTelemetry") saveTelemetry();
    if (event.target.id === "cancelTelemetry") renderDetail();
  });
}
function render() {
  const list = state.trekkers.map(enriched);
  $("#totalCount").textContent = String(list.length).padStart(2,"0");
  $("#highCount").textContent = String(list.filter(t => t.priority === "High").length).padStart(2,"0");
  $("#uncertainCount").textContent = String(list.filter(t => t.signal === "Weak" || t.signal === "None" || t.gpsConfidence === "Low" || t.gpsConfidence === "Very low" || t.pingAgeHours >= 3).length).padStart(2,"0");
  renderQueue();
  renderDetail();
  renderPlan(list.sort(sortByRisk));
  renderLab();
}
function renderQueue() {
  const query = $("#searchInput").value.trim().toLowerCase();
  const risk = $("#riskFilter").value;
  const sector = $("#sectorFilter").value;
  const filtered = state.trekkers.map(enriched).sort(sortByRisk).filter(t => {
    const matchesQuery = `${t.name} ${t.id} ${t.sector} ${t.sectorCode}`.toLowerCase().includes(query);
    return matchesQuery && (risk === "all" || t.priority === risk) && (sector === "all" || t.sectorCode === sector);
  });
  $("#trekkerList").innerHTML = filtered.length ? filtered.map(t => `
    <button class="trekker-row ${t.id === state.selectedId ? "selected" : ""}" type="button" data-id="${escapeHtml(t.id)}" aria-label="Inspect ${escapeHtml(t.name)}">
      <span class="person-cell"><span class="avatar">${initials(t.name)}</span><span class="person-info"><span class="person-name">${escapeHtml(t.name)}</span><span class="person-sub">${escapeHtml(t.id)} · ${escapeHtml(t.sectorCode)}</span></span></span>
      <span class="battery-cell">${t.battery}%<span class="battery-track"><span class="battery-fill" style="display:block;width:${Math.max(0,Math.min(100,t.battery))}%;background:${batteryColor(t.battery)}"></span></span></span>
      <span class="risk-badge ${riskClass(t.priority)}">${t.priority} · ${t.score}</span>
    </button>`).join("") : '<div class="empty-state"><h4>No matches</h4><p>Try a different name, priority or sector filter.</p></div>';
}
function renderDetail() {
  const t = state.trekkers.find(x => x.id === state.selectedId);
  if (!t) { $("#detailTitle").textContent = "No matching trekker"; $("#detailRiskBadge").textContent = "—"; $("#detailContent").innerHTML = ""; return; }
  const r = calculateRisk(t);
  $("#detailTitle").textContent = t.id;
  $("#detailRiskBadge").className = `risk-badge ${riskClass(r.priority)}`;
  $("#detailRiskBadge").textContent = `${r.priority} PRIORITY`;
  $("#detailContent").innerHTML = `
    <div class="profile-banner"><div><div class="profile-id">${escapeHtml(t.id)} / AGE ${escapeHtml(t.age)}</div><div class="profile-name">${escapeHtml(t.name)}</div><div class="profile-sector">${escapeHtml(t.sector)}</div></div><span class="risk-badge ${riskClass(r.priority)}">${r.priority}</span></div>
    <div class="metric-grid">
      <div class="metric"><div class="metric-label">Last known ping</div><div class="metric-value">${escapeHtml(t.lastPing)} AM</div><div class="metric-sub">${Number(t.pingAgeHours).toFixed(1)} hours old (simulated)</div></div>
      <div class="metric"><div class="metric-label">Estimated elevation</div><div class="metric-value">${Number(t.elevation).toLocaleString()} m</div><div class="metric-sub">${escapeHtml(t.terrain)} terrain</div></div>
      <div class="metric"><div class="metric-label">Signal integrity</div><div class="metric-value" style="color:${t.signal === "None" || t.signal === "Weak" ? "var(--amber)" : "var(--green)"}">${escapeHtml(t.signal)} (${t.signalBars}/4)</div><div class="metric-sub">Connectivity estimate</div></div>
      <div class="metric"><div class="metric-label">Battery estimate</div><div class="metric-value" style="color:${batteryColor(t.battery)}">${Number(t.battery)}%</div><div class="metric-sub">Estimated remaining power</div></div>
    </div>
    <div class="score-section">
      <div class="score-head"><span>HEURISTIC RISK SCORE</span><span class="score-number">${r.score}<small style="font-size:10px;color:#7d96a8"> / 100</small></span></div>
      <div class="score-track"><div class="score-fill" style="width:${r.score}%;background:${r.priority === "High" ? "var(--red)" : r.priority === "Medium" ? "var(--amber)" : "var(--green)"}"></div></div>
      <div class="factor-list">${r.factors.length ? r.factors.slice(0,5).map(f => `<div class="factor"><span>${escapeHtml(f.label)}</span><strong>+${f.points}</strong></div>`).join("") : '<div class="factor"><span>No major risk flags in current inputs</span><strong>+0</strong></div>'}</div>
    </div>
    <div class="profile-notes"><strong>Situation log:</strong> ${escapeHtml(t.notes || t.injury || "No additional report available.")}<br/><strong>Gear:</strong> ${escapeHtml(t.gear.join(", "))}</div>
    <div class="metric"><div class="metric-label">Location confidence indicator</div><div class="metric-value">${confidenceInfo(t).label}</div><div class="metric-sub">${escapeHtml(confidenceInfo(t).reason)}</div></div>
    <div class="section-label">EDIT SIMULATED TELEMETRY</div>
    <div class="field-grid">
      <div class="field"><label for="editBattery">Battery (%)</label><input id="editBattery" type="number" min="0" max="100" value="${Number(t.battery)}" /></div>
      <div class="field"><label for="editPingAge">Ping age (hours)</label><input id="editPingAge" type="number" min="0" max="72" step="0.1" value="${Number(t.pingAgeHours)}" /></div>
      <div class="field"><label for="editSignal">Signal quality</label><select id="editSignal">${options(["Strong","Moderate","Intermittent","Weak","None"],t.signal)}</select></div>
      <div class="field"><label for="editTerrain">Terrain risk</label><select id="editTerrain">${options(["Low","Medium","High","Very high"],t.terrain)}</select></div>
      <div class="field"><label for="editWeather">Weather exposure</label><select id="editWeather">${options(["Low","Medium","High"],t.weatherExposure)}</select></div>
      <div class="field"><label for="editConfidence">Location confidence</label><select id="editConfidence">${options(["High","Medium","Low","Very low"],t.gpsConfidence)}</select></div>
      <div class="field full"><label for="editInjury">Injury / welfare report</label><input id="editInjury" type="text" value="${escapeHtml(t.injury)}" /></div>
    </div>
    <div class="profile-actions"><button class="btn btn-primary" id="saveTelemetry" type="button">Save & recalculate</button><button class="btn btn-ghost" id="cancelTelemetry" type="button">Discard edits</button></div>`;
}
function options(values, selected) {
  return values.map(v => `<option value="${escapeHtml(v)}" ${v === selected ? "selected" : ""}>${escapeHtml(v)}</option>`).join("");
}
function saveTelemetry() {
  const t = state.trekkers.find(x => x.id === state.selectedId);
  if (!t) return;
  const battery = Number($("#editBattery").value);
  const age = Number($("#editPingAge").value);
  if (!Number.isFinite(battery) || battery < 0 || battery > 100 || !Number.isFinite(age) || age < 0 || age > 72) {
    toast("Enter battery 0–100 and ping age 0–72 hours."); return;
  }
  t.battery = battery;
  t.pingAgeHours = age;
  t.signal = $("#editSignal").value;
  t.signalBars = ({Strong:4,Moderate:3,Intermittent:2,Weak:1,None:0})[t.signal];
  t.terrain = $("#editTerrain").value;
  t.weatherExposure = $("#editWeather").value;
  t.gpsConfidence = $("#editConfidence").value;
  t.injury = $("#editInjury").value.trim() || "No injury reported";
  recordTelemetryUpdate(t, "Manual telemetry edit saved");
  render();
  toast(state.offline ? "Saved locally. Update queued until simulated reconnection." : "Telemetry saved. Priority queue and response plan updated.");
}
function renderPlan(list) {
  const high = list.filter(t => t.priority === "High");
  const medium = list.filter(t => t.priority === "Medium");
  $("#prioritySummary").textContent = high.length ? `${high.length} high-priority profile(s) need immediate human review. Start with the highest score, while verifying location confidence and the latest field reports.` : "No profile currently crosses the high-priority threshold. Continue welfare checks and monitor changing conditions.";
  $("#priorityChips").innerHTML = (high.length ? high : medium.slice(0,3)).slice(0,4).map(t => `<span class="name-chip">${escapeHtml(t.id)} · ${t.score}</span>`).join("") || '<span class="name-chip" style="background:#193a35;color:#7ce2be">No flagged profiles</span>';
  const groups = {};
  list.forEach(t => { if (!groups[t.sectorCode]) groups[t.sectorCode] = []; groups[t.sectorCode].push(t); });
  const sortedGroups = Object.entries(groups).map(([sector,people]) => ({sector, people, max:Math.max(...people.map(p=>p.score)), high:people.filter(p=>p.priority==="High").length})).sort((a,b)=>b.max-a.max);
  $("#teamAllocation").innerHTML = sortedGroups.slice(0,3).map((g,i) => `<div class="allocation-item"><strong>Team ${i+1} → ${escapeHtml(g.sector)}</strong><span>${g.people.length} trekker(s) listed · highest score ${g.max}/100${g.high ? ` · ${g.high} high priority` : ""}</span></div>`).join("");
  const gaps = [];
  if (list.some(t => t.pingAgeHours >= 3)) gaps.push("Request a fresh location ping; several reports are stale.");
  if (list.some(t => t.signal === "Weak" || t.signal === "None")) gaps.push("Try alternate radio relay points for weak or absent signals.");
  if (list.some(t => t.gpsConfidence === "Low" || t.gpsConfidence === "Very low")) gaps.push("Validate uncertain locations against trail logs or ranger reports.");
  if (list.some(t => Number(t.battery) < 20)) gaps.push("Prioritise contact attempts for critically low-battery devices.");
  if (list.some(t => t.terrain === "Very high" || t.weatherExposure === "High")) gaps.push("Check terrain and weather hazards before deploying ground teams.");
  $("#infoGaps").innerHTML = (gaps.length ? gaps : ["Continue routine check-ins and watch for changing telemetry."]).map(g => `<li>${escapeHtml(g)}</li>`).join("");
}
function confidenceInfo(t) {
  const base = ({ "High": 90, "Medium": 65, "Low": 35, "Very low": 15 })[t.gpsConfidence] ?? 35;
  const agePenalty = Math.min(45, Math.max(0, Number(t.pingAgeHours) || 0) * 7);
  const value = Math.max(5, Math.min(98, Math.round(base - agePenalty)));
  const label = value >= 70 ? "Higher" : value >= 40 ? "Moderate" : "Low";
  const reason = `Reported GPS confidence: ${t.gpsConfidence}; ping age: ${Number(t.pingAgeHours).toFixed(1)} hours. This is a demo indicator, not a measured GPS error radius.`;
  return { value, label, reason };
}
function persistQueue() { try { localStorage.setItem("lostSignalPending", JSON.stringify(state.pending)); } catch {} }
function persistAudit() { try { localStorage.setItem("lostSignalAudit", JSON.stringify(state.audit.slice(0,30))); } catch {} }
function logEvent(message) {
  const time = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  state.audit.unshift({ time, message }); state.audit = state.audit.slice(0, 30); persistAudit();
  if (document.querySelector("#auditLog")) renderAudit();
}
function recordTelemetryUpdate(t, description) {
  try { localStorage.setItem("lostSignalTelemetry", JSON.stringify(state.trekkers)); } catch {}
  const event = { eventId: `${t.id}-${Date.now()}-${Math.random().toString(16).slice(2,6)}`, trekkerId: t.id, at: new Date().toISOString(), description, snapshot: { battery: t.battery, pingAgeHours: t.pingAgeHours, signal: t.signal, terrain: t.terrain, weatherExposure: t.weatherExposure, gpsConfidence: t.gpsConfidence, injury: t.injury } };
  if (state.offline) {
    if (!state.pending.some(item => item.eventId === event.eventId)) state.pending.push(event);
    persistQueue(); logEvent(`${t.id}: update stored locally; awaiting connection`);
  } else {
    logEvent(`${t.id}: telemetry update accepted by simulated server`);
  }
  renderLab();
}
function toggleNetwork() {
  state.offline = !state.offline;
  logEvent(state.offline ? "Simulated network disconnected" : "Simulated network restored");
  renderLab();
  toast(state.offline ? "Simulation is offline. Updates will queue locally." : "Simulation online. Sync pending updates when ready.");
}
function syncQueue() {
  if (state.offline) { toast("Reconnect the simulated network before syncing."); return; }
  if (!state.pending.length) { toast("No pending updates to sync."); return; }
  const before = state.pending.length;
  // The prototype simulates a successful idempotent sync; it does not contact a real server.
  const seen = new Set();
  state.pending = state.pending.filter(item => { if (seen.has(item.eventId)) return false; seen.add(item.eventId); return false; });
  persistQueue();
  logEvent(`Simulated sync complete: ${before} queued update(s) processed; duplicate event IDs ignored`);
  renderLab(); render();
  toast(`${before} queued update(s) synced in the demo simulation.`);
}
function applyScenario(scenario) {
  const t = state.trekkers.find(x => x.id === state.selectedId);
  if (!t) return;
  if (scenario === "restore") {
    const original = state.original.find(x => x.id === t.id);
    Object.assign(t, JSON.parse(JSON.stringify(original)));
    try { localStorage.setItem("lostSignalTelemetry", JSON.stringify(state.trekkers)); } catch {}
    $("#scenarioMessage").textContent = `${t.id} restored to its original sample profile.`;
  } else {
    if (scenario === "battery") { t.battery = 5; $("#scenarioMessage").textContent = `${t.id}: battery set to 5%. Risk recalculated.`; }
    if (scenario === "injury") { t.injury = "Reported injury — urgent welfare assessment needed"; $("#scenarioMessage").textContent = `${t.id}: injury report added. Risk recalculated.`; }
    if (scenario === "stale") { t.pingAgeHours = 6; t.gpsConfidence = "Very low"; $("#scenarioMessage").textContent = `${t.id}: ping age set to 6 hours and location confidence lowered.`; }
    if (scenario === "weather") { t.weatherExposure = "High"; t.terrain = "Very high"; $("#scenarioMessage").textContent = `${t.id}: weather and terrain hazards increased.`; }
  }
  recordTelemetryUpdate(t, `What-if scenario applied: ${scenario}`);
  render();
  toast("Scenario applied. Review score, reasons and location confidence.");
}
function renderLab() {
  if (!$("#networkLabel")) return;
  $("#networkLabel").textContent = state.offline ? "SIMULATED OFFLINE" : "SIMULATED ONLINE";
  $("#networkLamp").classList.toggle("offline", state.offline);
  $("#toggleNetworkBtn").textContent = state.offline ? "Reconnect network" : "Go offline";
  $("#syncQueueBtn").disabled = state.offline || !state.pending.length;
  $("#queueCount").textContent = `${state.pending.length} queued`;
  $("#syncMessage").textContent = state.offline ? "Network disabled for demo. New updates remain in the local queue." : state.pending.length ? `${state.pending.length} update(s) waiting for simulated sync.` : "No pending updates.";
  const t = state.trekkers.find(x => x.id === state.selectedId) || state.trekkers[0];
  if (t) {
    const c = confidenceInfo(t);
    $("#confidenceName").textContent = t.id;
    $("#confidenceBadge").textContent = `${c.label.toUpperCase()} CONFIDENCE`;
    $("#confidenceBadge").className = `confidence-pill ${c.value >= 70 ? "high" : c.value < 40 ? "low" : ""}`;
    $("#confidenceFill").style.width = `${c.value}%`;
    $("#confidenceFill").style.background = c.value >= 70 ? "var(--green)" : c.value < 40 ? "var(--red)" : "var(--amber)";
    $("#confidenceReason").textContent = c.reason;
  }
  renderAudit();
}
function renderAudit() {
  const node = $("#auditLog"); if (!node) return;
  node.innerHTML = state.audit.length ? state.audit.slice(0,8).map(item => `<li><strong>${escapeHtml(item.time)}</strong> · ${escapeHtml(item.message)}</li>`).join("") : "<li>No events recorded yet.</li>";
}

let toastTimer;
function toast(message) {
  document.querySelector(".toast")?.remove();
  const node = document.createElement("div");
  node.className = "toast"; node.textContent = message; document.body.appendChild(node);
  clearTimeout(toastTimer); toastTimer = setTimeout(() => node.remove(), 2800);
}
function renderShoeTracker() {
  const t = state.trekkers.find(x => x.id === state.selectedId) || state.trekkers[0];
  if (!t) return;
  // Coordinates are synthetic demonstration values, not real people or live GPS fixes.
  const sectorOffsets = { "B-North": [0.014, 0.009], "C-East": [-0.008, 0.021], "A-South": [-0.019, -0.012] };
  const offset = sectorOffsets[t.sectorCode] || [0, 0];
  state.shoe.lat = 30.9 + offset[0]; state.shoe.lon = 79.0 + offset[1];
  $("#shoeTrackerName").textContent = `ST-${t.id}`;
  $("#shoeBattery").textContent = `${state.shoe.battery}%`;
  $("#shoeBattery").style.color = state.shoe.battery < 15 ? "var(--red)" : state.shoe.battery < 30 ? "var(--amber)" : "var(--green)";
  $("#shoeLastFix").textContent = state.shoe.lastFix;
  $("#shoePhoneStatus").textContent = state.shoe.phoneBroken ? "Broken / unavailable" : "Working";
  $("#shoeStatus").textContent = state.shoe.battery <= 5 ? "LOW BATTERY ALERT" : state.shoe.online ? "TRACKER ONLINE · DEMO" : "TRACKER SIGNAL UNAVAILABLE";
  $("#shoeStatusLamp").classList.toggle("offline", !state.shoe.online || state.shoe.battery <= 5);
  $("#shoeLat").textContent = state.shoe.lat.toFixed(5); $("#shoeLon").textContent = state.shoe.lon.toFixed(5);
  $("#shoeMapLabel").textContent = `${t.sectorCode.toUpperCase()} · SYNTHETIC DEMO`;
  $("#openMapBtn").href = `https://www.openstreetmap.org/?mlat=${state.shoe.lat}&mlon=${state.shoe.lon}#map=13/${state.shoe.lat}/${state.shoe.lon}`;
  $("#phoneBrokenBtn").textContent = state.shoe.phoneBroken ? "Restore phone status" : "Simulate phone broken";
  renderRescuePulse();
}

function saveSafeFootprint() {
  const t = state.trekkers.find(x => x.id === state.selectedId) || state.trekkers[0];
  if (!t) return;
  state.lastSafe = { id: t.id, lat: state.shoe.lat, lon: state.shoe.lon, time: new Date().toLocaleString(), sector: t.sector };
  renderRescuePulse();
  const msg = `Last Safe Footprint saved for ${t.id} (synthetic coordinates).`;
  $("#pulseEvent").textContent = msg; logEvent(msg);
}
function activateSilentSos() {
  const t = state.trekkers.find(x => x.id === state.selectedId) || state.trekkers[0];
  if (!t) return;
  if (!state.lastSafe) state.lastSafe = { id: t.id, lat: state.shoe.lat, lon: state.shoe.lon, time: new Date().toLocaleString(), sector: t.sector };
  state.sosActive = true;
  const msg = `DEMO SOS raised for ${t.id}. Operator review required; no real emergency service was contacted.`;
  $("#pulseEvent").textContent = msg; renderRescuePulse(); logEvent(msg); toast("Silent SOS demo activated. No real alert was sent.");
}
function resolveSilentSos() {
  state.sosActive = false;
  $("#pulseEvent").textContent = "Demo SOS marked reviewed by the operator. This does not represent a real rescue resolution.";
  renderRescuePulse(); logEvent(`Demo SOS reviewed for ${state.selectedId}`);
}
function renderRescuePulse() {
  if (!$("#rescuePulse")) return;
  const fp = state.lastSafe;
  $("#lastSafeCoords").textContent = fp ? `${fp.lat.toFixed(5)}, ${fp.lon.toFixed(5)}` : "No footprint saved yet";
  $("#lastSafeMeta").textContent = fp ? `${fp.id} · ${fp.sector} · ${fp.time} (demo)` : "Save a footprint from the current synthetic tracker position.";
  $("#sosStatus").textContent = state.sosActive ? "SOS ACTIVE · OPERATOR REVIEW" : "Standby · no active demo SOS";
  $("#sosMeta").textContent = state.sosActive ? `Incident for ${state.selectedId}; last footprint is preserved below. This is not a real dispatch.` : "SOS is a local prototype simulation; it will not contact emergency services.";
  $("#silentSosBtn").disabled = state.sosActive;
  $("#resolveSosBtn").disabled = !state.sosActive;
}

function receiveShoePing() {
  if (state.shoe.battery <= 5) { state.shoe.online = false; renderShoeTracker(); $("#shoeMessage").textContent = "Ping not sent: tracker battery critically low in this demo."; logEvent("ShoeTrace ping failed: simulated tracker battery critical"); return; }
  state.shoe.online = !state.offline; state.shoe.lastFix = new Date().toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"}) + " (simulated ping)";
  state.shoe.battery = Math.max(0, state.shoe.battery - 1); renderShoeTracker();
  if (state.offline) { state.pending.push({eventId:`SHOE-${Date.now()}`,trekkerId:state.selectedId,at:new Date().toISOString(),description:"ShoeTrace location ping",snapshot:{lat:state.shoe.lat,lon:state.shoe.lon,battery:state.shoe.battery}}); persistQueue(); renderLab(); $("#shoeMessage").textContent = "Tracker generated a demo ping; gateway is offline, so the update is queued locally. A real tracker needs its own working transmitter/gateway."; logEvent(`${state.selectedId}: ShoeTrace ping queued while offline`); }
  else { $("#shoeMessage").textContent = `Simulated tracker ping received for ${state.selectedId}. Coordinates are fictional demo values; no physical GPS is connected.`; logEvent(`${state.selectedId}: simulated independent tracker ping received`); }
}
function togglePhoneBroken() { state.shoe.phoneBroken = !state.shoe.phoneBroken; renderShoeTracker(); $("#shoeMessage").textContent = state.shoe.phoneBroken ? "Phone marked broken. The demo tracker still produces a ping because it is modelled as an independent device." : "Phone status restored in the simulation."; logEvent(state.shoe.phoneBroken ? "Phone failure simulated; independent tracker demo remains active" : "Phone restored in simulation"); }
init();
